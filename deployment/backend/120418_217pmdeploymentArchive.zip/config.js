/*
module.exports = {
  database: 'mongodb:/csulbDevs:491@ds117539.mlab.com:17539/wastenotwebapp',
  port: 3030,
  secret: "CsulbDevs123456789"
};
*/


module.exports = {
  database:
    'mongodb://csulbDevs:491@ds117539.mlab.com:17539/wastenotwebapp',
  port: 3030,
  secret: 'CsulbDevs2012312321'
};


/*
module.exports = {
  database:
    'mongodb://csulbdevs:491491b@ds125453.mlab.com:25453/wastenotwebapptwo',
  port: 3030,
  secret: 'CsulbDevs2012312321'
};
*/